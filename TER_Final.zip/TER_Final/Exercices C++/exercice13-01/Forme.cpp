#include "Forme.hpp"

Forme::~Forme() = default;
