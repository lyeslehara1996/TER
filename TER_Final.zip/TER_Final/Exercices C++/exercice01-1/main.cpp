
#include<iostream>

using namespace std;



int main(){
    
    
    std::cout << "hello word \n";

    return 0;
}
