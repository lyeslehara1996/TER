#include "es.h"

int somme(int &x, int &y)
{
return x + y;
}