#ifndef BANANE_H // Vérifie si MATH_UTILS_H n'est pas encore défini
#define BANANE_H
#include "Fruit.h"
#include<string>

class Banane : public Fruit
{
    
    public:
    
    Banane();
    
       
    };





#endif