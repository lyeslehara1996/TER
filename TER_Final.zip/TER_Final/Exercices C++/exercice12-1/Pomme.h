#ifndef POMME_H // Vérifie si MATH_UTILS_H n'est pas encore défini
#define POMME_H
#include "Fruit.h"
#include<string>
using namespace std;
class Pomme : public Fruit
{

    
    public:
    
    Pomme(std::string couleur);
    
       
    };





#endif