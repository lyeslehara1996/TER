#include<iostream>
#include "Fruit.h"
#include "Banane.h"
#include<string>


using namespace std;

Banane::Banane():Fruit("banane","jaune"){}