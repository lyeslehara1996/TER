#include<iostream>
#include "Fruit.h"
#include "Pomme.h"
#include<string>


using namespace std;

Pomme::Pomme(std::string couleur):Fruit("pomme",   couleur){}