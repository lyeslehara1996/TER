
#ifndef CONSTANTE_H // Vérifie si MATH_UTILS_H n'est pas encore défini
#define CONSTANTE_H
 
int  varmax = 100;

#endif