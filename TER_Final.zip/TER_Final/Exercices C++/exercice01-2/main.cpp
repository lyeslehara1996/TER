
#include<iostream>



int main(){

int a ;
float b ;



std::cout << "Donner deux valeur a et b "<<std::endl;
std::cin >> a;
std::cin >> b;

float somme = a + b;

std::cout <<"la somme de deux nombre a et b est : "<< somme <<std::endl;


    return 0;

}