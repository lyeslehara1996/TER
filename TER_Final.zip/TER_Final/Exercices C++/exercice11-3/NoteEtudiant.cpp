#include "NoteEtudiant.hpp"

NoteEtudiant::NoteEtudiant(const std::string& nom_, int note_)
    : nom(nom_), note(note_) {}
